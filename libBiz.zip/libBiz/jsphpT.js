//require("JsPHP")

require("PHP")

echo(123)