


global['oplog_add']=oplog_add
try{
    require("../libx/autoload.js")
}catch (e){}

try{
    require("../libx/db.js") 
}catch (e) {
    
}

function  oplog_add(rcd)
{

    log_fun_enter(arguments)
    if(isWinformEnv())
    {
        let rcdInShell=encodeURIComponent( JSON.stringify(rcd)  )
        let f=encodeURIComponent("__rootdir__/db/opLogColl.json");
        var hedtx=window.external.callFun("pdo_insert "+rcdInShell+" "+ f);
    }
    else
    {

        var file;
        if(__dirname.endsWith("libBiz"))
          file = __dirname + "/../db/opLogColl.json";
        else
            file = __dirname + "/db/opLogColl.json";

        console.log(":29 f=>"+file)
        pdo_insert(rcd, file);

    }


}


//oplog_add({"aa":111})



global["oplog_qry"] = oplog_qry;

  function oplog_qry(uname) {

  //  await import("../lowdbx/lowdbX.js")
    let dbfile = __dirname + "/../db/opLogColl.json";

    console.log("dbfile=>" + dbfile)
//  pdo_exec_insert()


    let _ = require('lodash');
    rzt = pdo_query({}, dbfile);


    rzt = _.orderBy(rzt, ['time'], ['desc']);
    rzt = rzt.slice(0, 300)
    return json_encode(rzt)

}



function oplog_qryINWeb()
{
    $().ready(function(){
        //do something
        var  rzt=  dsl_callFunCmdMode("oplog_qry"  )

        console.log(" rzt json str is :"+rzt.substring(0,250))

        try{
            json_decode (rzt)
        }catch (e)
        {
            return;
        }

        // alert(rzt)

        setTimeout(function () {
            columns= [
                { data: 'agtid' },
                { data: 'uname' },
                { data: '类型' },
                { data: 'time' }
            ]

            loadToDataTableV2(json_decode (rzt) ,"tab_oplog", columns,[[ 3, "desc" ]])
        },50)

    });

}




//oplog_add({})