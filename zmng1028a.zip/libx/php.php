<?php
echo(substr("abcde", 1, 2));

echo(sprintf("data:%s", 2003));