

// todo shgnxifen echo not ok...   show cn   chgong
//  limit also cfg
//