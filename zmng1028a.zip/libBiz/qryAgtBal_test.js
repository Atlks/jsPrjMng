

require("./qryAgtBal")



// DDDCB686535395BC


// B7A4A36327A085A7
// 111523,DDDCB686535395BC,B7A4A36327A085A7
token={}
token.agtid=111523
token.desCode="DDDCB686535395BC"
token.md5Code="B7A4A36327A085A7"
global['visa']=token
var token= global['visa']
var desCode=token.desCode
var agentid=token.agtid
var md5Code=token.md5Code
global['apiurl2023'] = "https://dtinterface.1saeda.com"

console.log(qryAgtBal())
