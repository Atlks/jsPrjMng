

require("./字串")
require("./系统")


显示(以xx开头("abc","A"))