# Summary

Date : 2023-09-04 17:21:48

Directory c:\\在修改的内容\\jbbot\\zmng

Total : 80 files,  3181 codes, 779 comments, 1620 blanks, all 5580 lines

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JavaScript | 47 | 2,327 | 649 | 1,294 | 4,270 |
| JSON | 16 | 348 | 0 | 2 | 350 |
| HTML | 4 | 339 | 122 | 138 | 599 |
| SQL | 3 | 114 | 6 | 138 | 258 |
| Markdown | 2 | 22 | 0 | 26 | 48 |
| Go | 2 | 17 | 2 | 10 | 29 |
| CSS | 1 | 7 | 0 | 2 | 9 |
| PHP | 2 | 4 | 0 | 7 | 11 |
| TypeScript | 2 | 2 | 0 | 2 | 4 |
| Log | 1 | 1 | 0 | 1 | 2 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 80 | 3,181 | 779 | 1,620 | 5,580 |
| . (Files) | 13 | 815 | 247 | 508 | 1,570 |
| .git-robot | 1 | 1 | 0 | 1 | 2 |
| db | 5 | 223 | 0 | 0 | 223 |
| doc | 3 | 31 | 2 | 21 | 54 |
| ini | 1 | 4 | 0 | 9 | 13 |
| libBiz | 4 | 91 | 24 | 53 | 168 |
| libx | 15 | 456 | 159 | 208 | 823 |
| lowdbx | 4 | 87 | 51 | 72 | 210 |
| node_modu | 17 | 1,278 | 261 | 601 | 2,140 |
| res | 10 | 84 | 1 | 24 | 109 |
| test | 7 | 111 | 34 | 123 | 268 |

Summary / [Details](details.md) / [Diff Summary](diff.md) / [Diff Details](diff-details.md)