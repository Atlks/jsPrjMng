


# electron invk async js fun prblm


only can invk sync meth

if drktl invk  async await fun..,jsut said v8 can new worker...

so invk async fun by cmd mode...

