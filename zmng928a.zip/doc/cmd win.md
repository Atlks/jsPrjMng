taskkill /f /t /im chrome.exe



taskkill /f /t /im electron.exe
taskkill /f /t /im node.exe