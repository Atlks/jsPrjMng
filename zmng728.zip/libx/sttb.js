

global['retry']=retry;
function  retry(f,reTrytimes,chkFun)
{

    var rzt_fnl;
    for(let i=0;i<reTrytimes;i++)
    {
          rzt_fnl=f();
        if(chkFun(rzt_fnl))
            break;
    }

    return rzt_fnl;


}
function  pipe()
{

}
function  setGlobalErrCatch()
{

}
function  mq()
{

}
function  callCmd()
{

}
function  setDaemon()
{

}


function  unittest()
{

}


function  callFunPressEx(fun,params)
{
    try {
        echo("\r\n\r\n");
        var funname = arguments.callee.name;
              arg = JSON.stringify(arguments);
      var ivkFundbg=  "*********=>" + funname + arg
      console.log(ivkFundbg)


        if( isset("window"))
            func =window[fun];
        else
            func =global[fun];


        if(func== undefined)
        {
            let eobj={"enterFunArgs": ivkFundbg,"msg":" cant find fun:"+fun}
            throw  eobj;
        }

        //window[cb];
        $r=   func.apply("thisobj", params);
        echo( sprintf("[%s] ret==>%s",fun,$r));
        echo("\r\n\r\n");
        return $r;
    } catch (e) {
        echo(e)
        $e2 = errorCast(e);
        let eobj={"type":"ex","name":"xxxex","msg":JSON.stringify($e2) ,"e":$e2};
        $rz=JSON.stringify(eobj);
    }


}


// ref  提升稳定性   文档 v2 x8x.docx