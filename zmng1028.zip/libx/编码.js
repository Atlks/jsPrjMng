


global['md5']=md5
/**
 *
 * @param msg
 */
function md5(msg) {
}