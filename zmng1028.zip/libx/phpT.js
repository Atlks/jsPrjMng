

// libdir="./"
// var {
//     isset, call_user_func,
//     echo,
//     substr,
//     console_log,
//     sprintf,
//     startwith,
//     str_replace,
//     strtolower,
//     strlen,
//     strpos,
//     trim,
//     sprintf, time
// } = require(libdir + 'php.js');
require( './php.js')
echo(999)