

const {split} = require("lodash");
global["split"]=split;

require("zmng/libx/fp_ati1990")
require("zmng/libx/enc")


global["somefun1111"]=xxx;