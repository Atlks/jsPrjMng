// require("php")
//
// echo(999)


require("ati1990fp4node")

echo(888)

require("esm-hook");
const chalk = require('chalk').default
console.log(chalk.blue('你好'))

console.log(chalk.bgYellow(chalk.blue('你好')))



echo( json_encode(159) )


require("fp_ati1990")


log(123)