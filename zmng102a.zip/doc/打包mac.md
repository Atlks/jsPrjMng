

下载npm node
进入主目录zmng，按照模块

 npm i  electron

     npm i node-fetch
npm i crypto-js



    npm i chalk
    npm i esm-hook
    npm i  express
npm i  silly-datetime

npm i    node-fetch crypto-js express chalk esm-hook silly-datetime moment lowdb lodash node-xlsx
npm i  cookie-parser

直接electron xx.js模式运行找不到文件。。

增加package。js,,,指明 "main": "dsktp.js",


启动 npm start...



路径开头/ 开头路径问题
shell路径空格问题，增加双引号包裹


shell脚本command文件授权问题
sudo chmod -R 777  
拖入对应文件，给与授权。。以后就可以双击打开了。。



不能copy paste 问题，
需要开发menu，才能自动绑定热键即可。。不要隐藏默认的menu。在mac直显示在最上边，不影响使用。。