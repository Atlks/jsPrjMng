

cd pkgfold
add package.json


{
"main": "lowdbX.js",
"name": "@attilax/lowdbx",
"version": "1.0.0",
"type": "module",
"dependencies": {
}
}




cfg name n main js path..

then


//  cd zmng/lowdbx
//  npm publish --access=public



更新已发布的包

更新包和发布包的命令是一样的，更新包只需修改package.json里面的version字段，也可以使用npm 自带的版本控制命令修改版本号，更新的步骤为：

    修改版本号
    npm publish
