// require("php")
//
//
// echo(111)







require("zmng/libx/易语言")
显示(111)





显示(当前时间())


显示(时间戳())