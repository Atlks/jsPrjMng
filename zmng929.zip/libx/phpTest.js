var {
    echo,
    substr,
    console_log,
    sprintf,
    startwith,
    str_replace,
    strtolower,
    strlen,
    strpos,
    trim,
    sprintf
} = require('./php.js');

echo(substr("abcde", 1, 2));

echo(sprintf("data:%s", 2003));