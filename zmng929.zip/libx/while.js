


function  whilex(exps,foreachFun)
{
    while(exps)
    {
        foreachFun ()
        i++
    }

}