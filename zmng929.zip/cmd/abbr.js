
const fs = require('fs');
const {dirname} = require("path");

f="c:/w/egls850wd.txt"
f="C:\\w\\wd850cnKeys.txt"

const data = fs.readFileSync(f, 'UTF-8');

// split the contents by new line
const lines = data.split(/\r?\n/);

// print all lines
lines.forEach((line) => {
    console.log(line);
    line=line.trim();
    arr=line.split("\t")
    cn=arr[0]
    keys=arr[1]

    newline=""
    if(line.length<=4)
    {
        newline=line
    }else
    {
        firstCh=line.substr(0,1)
        otherStr=line.substr(1,100)

        const reg = /[aeiou]/ig
        otherStr=otherStr.replaceAll(reg,"")

        newline=firstCh+otherStr
    }



   let newfile="00.txt"
   // fs.mkdirSync(dirname(newfile) , {recursive: true});
    //   fs.mkdirSync(appRoot + '/css
   // newline="::"+newline+"::"
    fs.appendFileSync(newfile, newline +"\n");

});

//fs.close()