
const fs = require('fs');
const {dirname} = require("path");

f="c:/w/egls850wd.txt"
f="C:\\w\\wd850cnKeys.txt"

const data = fs.readFileSync(f, 'UTF-8');

// split the contents by new line
const lines = data.split(/\r?\n/);

// print all lines
lines.forEach((line) => {
    console.log(line);
    line=line.trim();
    arr=line.split("\t")
    cn=arr[0]
    keys=arr[1]


 let  txt=fs.readFileSync("C:\\w\\hotstrings-master\\hotstr_tmplt.au3")
  txt=txt.toString()
    txt=txt.replace("@hotkeys",keys)
    txt=txt.replace("@输出",cn)
    txt=txt.replaceAll("ngemFunname",keys+"Funame")


    bkspc=geneBkspc(keys)
    txt=txt.replaceAll("{BACKSPACE}",bkspc)



   let newfile="ipt.au3"

    fs.appendFileSync(newfile, txt +"\n");

});


function  geneBkspc(keys)
{
    return "{BACKSPACE}".repeat(keys.length+1)
}
//fs.close()