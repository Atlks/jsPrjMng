//import("@attilax/fp")


 require("fp_ati1990")
 //require ("@attilax/fp")
// import( __dirname+"/../node_modules/fp_ati1990.js")
//import( __dirname+"/../node_modules/php.js")
//require("php")
echo(111)


显示(111)