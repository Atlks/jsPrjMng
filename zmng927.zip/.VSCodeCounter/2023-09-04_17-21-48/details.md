# Details

Date : 2023-09-04 17:21:48

Directory c:\\在修改的内容\\jbbot\\zmng

Total : 80 files,  3181 codes, 779 comments, 1620 blanks, all 5580 lines

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [.git-robot/git-robot.log](/.git-robot/git-robot.log) | Log | 1 | 0 | 1 | 2 |
| [agt.js](/agt.js) | JavaScript | 62 | 5 | 23 | 90 |
| [cfg.js](/cfg.js) | JavaScript | 1 | 0 | 0 | 1 |
| [ctrl.js](/ctrl.js) | JavaScript | 12 | 1 | 5 | 18 |
| [db/coll_user.json](/db/coll_user.json) | JSON | 6 | 0 | 0 | 6 |
| [db/db400.json](/db/db400.json) | JSON | 7 | 0 | 0 | 7 |
| [db/opLogColl.json](/db/opLogColl.json) | JSON | 140 | 0 | 0 | 140 |
| [db/scoreLogColl.json](/db/scoreLogColl.json) | JSON | 56 | 0 | 0 | 56 |
| [db/userColl.json](/db/userColl.json) | JSON | 14 | 0 | 0 | 14 |
| [doc/playstatRet.json](/doc/playstatRet.json) | JSON | 1 | 0 | 0 | 1 |
| [doc/publish npm pkg.md](/doc/publish%20npm%20pkg.md) | Markdown | 18 | 0 | 17 | 35 |
| [doc/starter.go](/doc/starter.go) | Go | 12 | 2 | 4 | 18 |
| [dsktp.js](/dsktp.js) | JavaScript | 70 | 28 | 27 | 125 |
| [dsl.sql](/dsl.sql) | SQL | 26 | 2 | 27 | 55 |
| [dslAsm.sql](/dslAsm.sql) | SQL | 43 | 2 | 47 | 92 |
| [dslV3.sql](/dslV3.sql) | SQL | 45 | 2 | 64 | 111 |
| [index.html](/index.html) | HTML | 59 | 2 | 30 | 91 |
| [index.js](/index.js) | JavaScript | 75 | 35 | 61 | 171 |
| [ini/bp.md](/ini/bp.md) | Markdown | 4 | 0 | 9 | 13 |
| [libBiz/api——dep.js](/libBiz/api%E2%80%94%E2%80%94dep.js) | JavaScript | 87 | 23 | 45 | 155 |
| [libBiz/exec.php](/libBiz/exec.php) | PHP | 1 | 0 | 6 | 7 |
| [libBiz/jsphpT.js](/libBiz/jsphpT.js) | JavaScript | 2 | 1 | 2 | 5 |
| [libBiz/t.ts](/libBiz/t.ts) | TypeScript | 1 | 0 | 0 | 1 |
| [libx/aes.js](/libx/aes.js) | JavaScript | 61 | 11 | 22 | 94 |
| [libx/agt.js](/libx/agt.js) | JavaScript | 62 | 5 | 23 | 90 |
| [libx/autoldTst.js](/libx/autoldTst.js) | JavaScript | 4 | 0 | 8 | 12 |
| [libx/autoload.js](/libx/autoload.js) | JavaScript | 22 | 10 | 14 | 46 |
| [libx/callFun.js](/libx/callFun.js) | JavaScript | 46 | 79 | 30 | 155 |
| [libx/dsl.js](/libx/dsl.js) | JavaScript | 16 | 4 | 10 | 30 |
| [libx/enc.js](/libx/enc.js) | JavaScript | 23 | 6 | 8 | 37 |
| [libx/file.js](/libx/file.js) | JavaScript | 6 | 0 | 7 | 13 |
| [libx/http.js](/libx/http.js) | JavaScript | 68 | 11 | 36 | 115 |
| [libx/php.js](/libx/php.js) | JavaScript | 112 | 18 | 35 | 165 |
| [libx/php.php](/libx/php.php) | PHP | 3 | 0 | 1 | 4 |
| [libx/phpT.htm.html](/libx/phpT.htm.html) | HTML | 14 | 0 | 7 | 21 |
| [libx/phpT.js](/libx/phpT.js) | JavaScript | 2 | 15 | 2 | 19 |
| [libx/phpTest.js](/libx/phpTest.js) | JavaScript | 15 | 0 | 2 | 17 |
| [libx/pkgtst.js](/libx/pkgtst.js) | JavaScript | 2 | 0 | 3 | 5 |
| [lowdbx/lowdbTst.js](/lowdbx/lowdbTst.js) | JavaScript | 13 | 12 | 24 | 49 |
| [lowdbx/lowdbX.js](/lowdbx/lowdbX.js) | JavaScript | 60 | 39 | 47 | 146 |
| [lowdbx/package.json](/lowdbx/package.json) | JSON | 8 | 0 | 1 | 9 |
| [lowdbx/userColl.json](/lowdbx/userColl.json) | JSON | 6 | 0 | 0 | 6 |
| [node_modu/aes.js](/node_modu/aes.js) | JavaScript | 61 | 11 | 22 | 94 |
| [node_modu/api.js](/node_modu/api.js) | JavaScript | 87 | 24 | 85 | 196 |
| [node_modu/api2023jb.js](/node_modu/api2023jb.js) | JavaScript | 234 | 58 | 137 | 429 |
| [node_modu/apidoc.json](/node_modu/apidoc.json) | JSON | 5 | 0 | 0 | 5 |
| [node_modu/autoload.js](/node_modu/autoload.js) | JavaScript | 22 | 10 | 14 | 46 |
| [node_modu/core.js](/node_modu/core.js) | JavaScript | 8 | 0 | 5 | 13 |
| [node_modu/dsl.js](/node_modu/dsl.js) | JavaScript | 16 | 4 | 10 | 30 |
| [node_modu/dslParse.js](/node_modu/dslParse.js) | JavaScript | 219 | 23 | 99 | 341 |
| [node_modu/enc.js](/node_modu/enc.js) | JavaScript | 33 | 6 | 8 | 47 |
| [node_modu/exprs.js](/node_modu/exprs.js) | JavaScript | 79 | 15 | 10 | 104 |
| [node_modu/file.js](/node_modu/file.js) | JavaScript | 33 | 5 | 10 | 48 |
| [node_modu/fp_ati1990.js](/node_modu/fp_ati1990.js) | JavaScript | 199 | 43 | 76 | 318 |
| [node_modu/http.js](/node_modu/http.js) | JavaScript | 74 | 13 | 36 | 123 |
| [node_modu/package.json](/node_modu/package.json) | JSON | 8 | 0 | 1 | 9 |
| [node_modu/php.js](/node_modu/php.js) | JavaScript | 137 | 21 | 57 | 215 |
| [node_modu/secury.js](/node_modu/secury.js) | JavaScript | 0 | 0 | 1 | 1 |
| [node_modu/ui.js](/node_modu/ui.js) | JavaScript | 63 | 28 | 30 | 121 |
| [oplog.htm](/oplog.htm) | HTML | 121 | 60 | 49 | 230 |
| [res/agtBal.json](/res/agtBal.json) | JSON | 1 | 0 | 0 | 1 |
| [res/apidoc.json](/res/apidoc.json) | JSON | 5 | 0 | 0 | 5 |
| [res/g.go](/res/g.go) | Go | 5 | 0 | 6 | 11 |
| [res/kexiafen.json](/res/kexiafen.json) | JSON | 9 | 0 | 0 | 9 |
| [res/kill.js](/res/kill.js) | JavaScript | 9 | 0 | 5 | 14 |
| [res/playerQryRzt.json](/res/playerQryRzt.json) | JSON | 20 | 0 | 0 | 20 |
| [res/sheofenRzt.json](/res/sheofenRzt.json) | JSON | 12 | 0 | 0 | 12 |
| [res/style.css](/res/style.css) | CSS | 7 | 0 | 2 | 9 |
| [res/ts11.ts](/res/ts11.ts) | TypeScript | 1 | 0 | 2 | 3 |
| [res/web.js](/res/web.js) | JavaScript | 15 | 1 | 9 | 25 |
| [shangxiafen.htm](/shangxiafen.htm) | HTML | 145 | 60 | 52 | 257 |
| [shangxiafen.js](/shangxiafen.js) | JavaScript | 141 | 49 | 114 | 304 |
| [test/ati1990fp4nodeTest.js](/test/ati1990fp4nodeTest.js) | JavaScript | 2 | 0 | 7 | 9 |
| [test/dblowT.js](/test/dblowT.js) | JavaScript | 12 | 10 | 24 | 46 |
| [test/lowDbTest.js](/test/lowDbTest.js) | JavaScript | 23 | 9 | 23 | 55 |
| [test/lowdbTst.js](/test/lowdbTst.js) | JavaScript | 10 | 3 | 14 | 27 |
| [test/pkgTest.js](/test/pkgTest.js) | JavaScript | 9 | 3 | 12 | 24 |
| [test/userColl4.json](/test/userColl4.json) | JSON | 50 | 0 | 0 | 50 |
| [test/web.js](/test/web.js) | JavaScript | 5 | 9 | 43 | 57 |
| [web.js](/web.js) | JavaScript | 15 | 1 | 9 | 25 |

[Summary](results.md) / Details / [Diff Summary](diff.md) / [Diff Details](diff-details.md)