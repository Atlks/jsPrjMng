function 显示退出按钮区域() {


    console.log("显示退出按钮区域...")


}


function 转到主界面() {
    console.log("转到主界面 welcome")
}


function 关闭登录区域() {

    console.log("关闭登录区域...")

}



function 退出登录区域() {

}
