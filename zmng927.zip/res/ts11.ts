

console.log(99) ;