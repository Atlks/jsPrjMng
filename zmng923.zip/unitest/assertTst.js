const assert = require('assert')


assert(true, "xxx")

assert(false, "yyy")