const winston = require('winston')
winston.log('info', 'Hello World!')
winston.info('Hello World')



const winlogger = require("logger");
winlogger.info("日志内容");