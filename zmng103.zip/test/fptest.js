require("@attilax/fp")

echo(111)

// npm i  @attilax/fp@1.6.0