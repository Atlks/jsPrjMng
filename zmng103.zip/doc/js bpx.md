
dont use foreach ,bcs async ,maybe somew time bug ..use
for(var i=0 ) repls foreach is more less bug.



JavaScript 不需要声明变量类型，类型转换基本不会用到。因此，代码读起来非常清晰，不过却存在潜藏错误的风险。

在这一点上，同否赞同 Java 的作法由你决定。我在十年前认为获取更多确定性的开销是值得的。但现在我认为那样做的代价太大，还是用 JavaScript 的方式做事要容易得多。

use ex rpls rtvl
